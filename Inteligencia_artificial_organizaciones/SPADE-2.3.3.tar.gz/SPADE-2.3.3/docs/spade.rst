spade package
=============

Submodules
----------

spade.agent module
------------------

.. automodule:: spade.agent
    :members:
    :undoc-members:
    :show-inheritance:

spade.behaviour module
----------------------

.. automodule:: spade.behaviour
    :members:
    :undoc-members:
    :show-inheritance:

spade.cli module
----------------

.. automodule:: spade.cli
    :members:
    :undoc-members:
    :show-inheritance:

spade.message module
--------------------

.. automodule:: spade.message
    :members:
    :undoc-members:
    :show-inheritance:

spade.spade module
------------------

.. automodule:: spade.spade
    :members:
    :undoc-members:
    :show-inheritance:

spade.template module
---------------------

.. automodule:: spade.template
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: spade
    :members:
    :undoc-members:
    :show-inheritance:
