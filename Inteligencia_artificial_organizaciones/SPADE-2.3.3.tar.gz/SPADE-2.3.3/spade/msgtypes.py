# -*- coding: utf-8 -*-
# Message types (that an agent can receive)
MSG_ACL = "ACL"
MSG_IQ = "IQ"
MSG_PRESENCE = "PRESENCE"
MSG_JABBER = "JABBER"
